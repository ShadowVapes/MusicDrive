// Shared helpers for Tesó Player (GitHub Pages only)

const CFG_KEY = "teso_player_github_cfg_v1";
const GH_ROOT = "docs"; // repo path that GitHub Pages serves as site root

export function loadCfg() {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    const cfg = raw ? JSON.parse(raw) : {};
    return {
      owner: cfg.owner || "",
      repo: cfg.repo || "",
      branch: cfg.branch || "main",
      token: cfg.token || ""
    };
  } catch {
    return { owner: "", repo: "", branch: "main", token: "" };
  }
}

export function saveCfg(cfg) {
  localStorage.setItem(
    CFG_KEY,
    JSON.stringify({
      owner: (cfg.owner || "").trim(),
      repo: (cfg.repo || "").trim(),
      branch: (cfg.branch || "main").trim() || "main",
      token: (cfg.token || "").trim()
    })
  );
}

export const PATHS = {
  siteTracks: "./data/tracks.json",
  ghTracks: `${GH_ROOT}/data/tracks.json`,
  ghAudioDir: `${GH_ROOT}/media/audio`,
  ghCoverDir: `${GH_ROOT}/media/covers`
};

export function normRelPath(p) {
  if (!p) return "";
  // allow "media/..." or "./media/..." or "/media/..."
  return p.replace(/^\.\//, "").replace(/^\//, "");
}

export function splitPublishers(s) {
  return String(s || "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);
}

export function joinPublishers(arr) {
  if (!Array.isArray(arr)) return String(arr || "");
  return arr.filter(Boolean).join(", ");
}

export function formatTime(sec) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const s = Math.floor(sec);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

export async function loadTracksFromSite({ cacheBust = true } = {}) {
  const url = PATHS.siteTracks + (cacheBust ? `?v=${Date.now()}` : "");
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error("Nem tudtam betölteni a tracklistát.");
  const json = await res.json();
  return Array.isArray(json?.tracks) ? json.tracks : [];
}

function ghHeaders(cfg) {
  const h = {
    Accept: "application/vnd.github+json"
  };
  if (cfg?.token) h.Authorization = `Bearer ${cfg.token}`;
  return h;
}

export async function ghGetContent(path, cfg) {
  const url = `https://api.github.com/repos/${cfg.owner}/${cfg.repo}/contents/${encodeURIComponent(
    path
  )}?ref=${encodeURIComponent(cfg.branch || "main")}`;
  const res = await fetch(url, { headers: ghHeaders(cfg) });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`GitHub GET hiba (${res.status}): ${t || res.statusText}`);
  }
  return res.json();
}

export async function ghPutFile({ path, contentBase64, message, cfg, sha }) {
  const url = `https://api.github.com/repos/${cfg.owner}/${cfg.repo}/contents/${encodeURIComponent(
    path
  )}`;
  const body = {
    message,
    content: contentBase64,
    branch: cfg.branch || "main"
  };
  if (sha) body.sha = sha;

  const res = await fetch(url, {
    method: "PUT",
    headers: { ...ghHeaders(cfg), "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`GitHub PUT hiba (${res.status}): ${t || res.statusText}`);
  }
  return res.json();
}

export async function ghDeleteFile({ path, message, cfg, sha }) {
  const url = `https://api.github.com/repos/${cfg.owner}/${cfg.repo}/contents/${encodeURIComponent(
    path
  )}`;
  const body = {
    message,
    sha,
    branch: cfg.branch || "main"
  };

  const res = await fetch(url, {
    method: "DELETE",
    headers: { ...ghHeaders(cfg), "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`GitHub DELETE hiba (${res.status}): ${t || res.statusText}`);
  }
  return res.json();
}

export async function fileToBase64(file) {
  const buf = new Uint8Array(await file.arrayBuffer());
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < buf.length; i += chunk) {
    binary += String.fromCharCode(...buf.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function makeId() {
  return (
    Math.random().toString(36).slice(2, 10) +
    "-" +
    Date.now().toString(36).slice(-4)
  );
}

export function detectSourceType(url) {
  const u = String(url || "").toLowerCase();
  if (u.includes("youtube.com") || u.includes("youtu.be")) return "youtube";
  if (u.includes("open.spotify.com")) return "spotify";
  return "";
}

export async function resolveFromUrl(url) {
  const type = detectSourceType(url);
  if (!type) throw new Error("Csak YouTube vagy Spotify linket értek.");

  const endpoint =
    type === "youtube"
      ? `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(
          url
        )}`
      : `https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`;

  const res = await fetch(endpoint);
  if (!res.ok) throw new Error("Nem jött válasz az oEmbed-től.");
  const data = await res.json();

  const out = {
    sourceType: type,
    sourceUrl: url,
    title: "",
    publishers: [],
    coverUrl: data.thumbnail_url || ""
  };

  // YouTube: title + author_name
  if (type === "youtube") {
    out.title = String(data.title || "").trim();
    const a = String(data.author_name || "").trim();
    out.publishers = a ? [a] : [];
    return out;
  }

  // Spotify: title gyakran ilyen: "Artist - Track"
  const t = String(data.title || "").trim();
  if (t.includes(" - ")) {
    const [a, b] = t.split(" - ");
    out.publishers = [a.trim()].filter(Boolean);
    out.title = b ? b.trim() : t;
  } else {
    out.title = t;
    const a = String(data.author_name || "").trim();
    out.publishers = a ? [a] : [];
  }
  return out;
}

export function coverSrc(track) {
  const cp = normRelPath(track?.coverPath || "");
  if (cp) return "./" + cp;
  const cu = String(track?.coverUrl || "").trim();
  if (cu) return cu;
  return "";
}

export function audioSrc(track) {
  const ap = normRelPath(track?.audioPath || "");
  if (ap) return "./" + ap;
  return "";
}
