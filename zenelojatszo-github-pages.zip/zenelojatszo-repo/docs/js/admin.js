import {
  loadCfg,
  saveCfg,
  PATHS,
  loadTracksFromSite,
  coverSrc,
  audioSrc,
  splitPublishers,
  joinPublishers,
  makeId,
  resolveFromUrl,
  fileToBase64,
  ghGetContent,
  ghPutFile,
  ghDeleteFile,
  normRelPath
} from "./common.js";

const el = {
  connState: document.getElementById("connState"),
  ghOwner: document.getElementById("ghOwner"),
  ghRepo: document.getElementById("ghRepo"),
  ghBranch: document.getElementById("ghBranch"),
  ghToken: document.getElementById("ghToken"),
  saveConnBtn: document.getElementById("saveConnBtn"),
  testConnBtn: document.getElementById("testConnBtn"),

  newBtn: document.getElementById("newBtn"),
  trackCount: document.getElementById("trackCount"),
  trackList: document.getElementById("trackList"),

  saveState: document.getElementById("saveState"),
  sourceUrl: document.getElementById("sourceUrl"),
  title: document.getElementById("title"),
  publishers: document.getElementById("publishers"),
  coverUrl: document.getElementById("coverUrl"),
  coverFile: document.getElementById("coverFile"),
  audioFile: document.getElementById("audioFile"),

  previewCover: document.getElementById("previewCover"),
  previewTitle: document.getElementById("previewTitle"),
  previewSub: document.getElementById("previewSub"),
  delBtn: document.getElementById("delBtn"),
  openFileBtn: document.getElementById("openFileBtn")
};

let cfg = loadCfg();
let tracks = [];
let selectedId = "";
let saveTimer = null;
let resolveTimer = null;

function setPill(pill, text, kind) {
  pill.textContent = text;
  pill.classList.remove("warn", "ok");
  if (kind) pill.classList.add(kind);
}

function cfgFromInputs() {
  return {
    owner: el.ghOwner.value.trim(),
    repo: el.ghRepo.value.trim(),
    branch: (el.ghBranch.value.trim() || "main").trim(),
    token: el.ghToken.value.trim()
  };
}

function applyCfgToInputs() {
  el.ghOwner.value = cfg.owner || "";
  el.ghRepo.value = cfg.repo || "";
  el.ghBranch.value = cfg.branch || "main";
  el.ghToken.value = cfg.token || "";
}

function currentTrack() {
  return tracks.find((t) => t.id === selectedId) || null;
}

function htmlEscape(s) {
  return String(s || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function renderList() {
  el.trackCount.textContent = String(tracks.length);
  el.trackList.innerHTML = "";

  for (const t of tracks) {
    const item = document.createElement("div");
    item.className = "trackitem" + (t.id === selectedId ? " active" : "");
    const csrc = coverSrc(t);
    item.innerHTML = `
      <div class="ti-cover">
        ${csrc ? `<img loading="lazy" src="${htmlEscape(csrc)}" alt="" />` : ""}
      </div>
      <div class="ti-text">
        <div class="ti-title">${htmlEscape(t.title || "—")}</div>
        <div class="ti-sub">${htmlEscape(joinPublishers(t.publishers || []) || "—")}</div>
      </div>
    `;
    item.addEventListener("click", () => select(t.id));
    el.trackList.appendChild(item);
  }
}

function renderEditor() {
  const t = currentTrack();
  if (!t) {
    el.sourceUrl.value = "";
    el.title.value = "";
    el.publishers.value = "";
    el.coverUrl.value = "";
    el.previewCover.innerHTML = "";
    el.previewTitle.textContent = "—";
    el.previewSub.textContent = "—";
    el.openFileBtn.href = "#";
    el.openFileBtn.style.pointerEvents = "none";
    el.openFileBtn.style.opacity = ".55";
    return;
  }

  el.sourceUrl.value = t.sourceUrl || "";
  el.title.value = t.title || "";
  el.publishers.value = joinPublishers(t.publishers || []);
  el.coverUrl.value = t.coverUrl || "";

  const csrc = coverSrc(t);
  el.previewCover.innerHTML = csrc ? `<img src="${htmlEscape(csrc)}" alt="" />` : "";
  el.previewTitle.textContent = t.title || "—";
  el.previewSub.textContent = joinPublishers(t.publishers || []) || "—";

  const asrc = audioSrc(t);
  el.openFileBtn.href = asrc || "#";
  el.openFileBtn.style.pointerEvents = asrc ? "auto" : "none";
  el.openFileBtn.style.opacity = asrc ? "1" : ".55";
}

function select(id) {
  selectedId = id;
  renderList();
  renderEditor();
  setPill(el.saveState, "—");
}

function patchCurrent(patch) {
  const t = currentTrack();
  if (!t) return;

  Object.assign(t, patch);
  t.updatedAt = Date.now();
  renderList();
  renderEditor();
  scheduleSave();
}

function scheduleSave(immediate = false) {
  clearTimeout(saveTimer);
  setPill(el.saveState, "Mentés…", "warn");
  saveTimer = setTimeout(saveNow, immediate ? 10 : 1100);
}

function base64Text(str) {
  // utf-8 safe
  return btoa(unescape(encodeURIComponent(str)));
}

function requireConn() {
  const c = cfgFromInputs();
  if (!c.owner || !c.repo || !c.branch || !c.token) {
    throw new Error("Nincs megadva minden GitHub adat (owner/repo/branch/token).");
  }
  return c;
}

async function testConn() {
  try {
    cfg = cfgFromInputs();
    saveCfg(cfg);
    const c = requireConn();
    await ghGetContent(PATHS.ghTracks, c);
    setPill(el.connState, "ok", "ok");
  } catch (e) {
    setPill(el.connState, "nincs bekötve", "warn");
    alert(String(e?.message || e));
  }
}

function extFromFile(file, fallback) {
  const n = String(file?.name || "").toLowerCase();
  if (n.endsWith(".mp3")) return ".mp3";
  if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return ".jpg";
  if (n.endsWith(".png")) return ".png";
  if (n.endsWith(".webp")) return ".webp";
  return fallback;
}

async function uploadToRepo({ file, dirPath, kind }) {
  const c = requireConn();

  // quick size guard (GitHub content API max is ~100MB)
  const max = 95 * 1024 * 1024;
  if (file.size > max) throw new Error(`Túl nagy fájl (${Math.round(file.size / 1024 / 1024)}MB).`);

  const ext = extFromFile(file, kind === "audio" ? ".mp3" : ".jpg");
  const name = `${selectedId}-${Date.now()}${ext}`;
  const fullPath = `${dirPath}/${name}`;

  const b64 = await fileToBase64(file);
  await ghPutFile({
    path: fullPath,
    contentBase64: b64,
    message: `Upload ${kind}: ${name}`,
    cfg: c
  });

  // site path = remove "docs/"
  return fullPath.replace(/^docs\//, "");
}

async function saveTracksJson() {
  const c = requireConn();

  // fetch sha
  const existing = await ghGetContent(PATHS.ghTracks, c);
  const sha = existing.sha;

  const payload = JSON.stringify({ tracks }, null, 2);
  await ghPutFile({
    path: PATHS.ghTracks,
    contentBase64: base64Text(payload),
    message: `Update tracks.json (${new Date().toISOString()})`,
    cfg: c,
    sha
  });
}

async function saveNow() {
  const t = currentTrack();
  if (!t) return;

  try {
    cfg = cfgFromInputs();
    saveCfg(cfg);

    const c = requireConn();
    setPill(el.connState, "ok", "ok");

    // upload files if selected
    const audio = el.audioFile.files?.[0];
    const cover = el.coverFile.files?.[0];

    if (audio) {
      const sitePath = await uploadToRepo({
        file: audio,
        dirPath: PATHS.ghAudioDir,
        kind: "audio"
      });
      t.audioPath = normRelPath(sitePath);
      el.audioFile.value = "";
    }

    if (cover) {
      const sitePath = await uploadToRepo({
        file: cover,
        dirPath: PATHS.ghCoverDir,
        kind: "cover"
      });
      t.coverPath = normRelPath(sitePath);
      el.coverFile.value = "";
    }

    await saveTracksJson();

    setPill(el.saveState, "Mentve", "ok");
    renderList();
    renderEditor();
  } catch (e) {
    console.error(e);
    setPill(el.saveState, "Hiba", "warn");
    // ha nincs token, ne csipogjon folyamatosan
    if (String(e?.message || e).includes("Nincs megadva")) {
      setPill(el.saveState, "Nincs token", "warn");
      return;
    }
    alert(String(e?.message || e));
  }
}

/* delete */
async function deleteCurrent() {
  const t = currentTrack();
  if (!t) return;
  if (!confirm("Fixen töröljük?")) return;

  try {
    cfg = cfgFromInputs();
    saveCfg(cfg);
    const c = requireConn();

    // delete associated files if exist
    const delIf = async (siteRelPath) => {
      const rel = normRelPath(siteRelPath || "");
      if (!rel) return;
      const full = `docs/${rel}`;
      try {
        const info = await ghGetContent(full, c);
        await ghDeleteFile({
          path: full,
          sha: info.sha,
          message: `Delete file: ${rel}`,
          cfg: c
        });
      } catch {
        // ignore
      }
    };

    await delIf(t.audioPath);
    await delIf(t.coverPath);

    tracks = tracks.filter((x) => x.id !== t.id);
    selectedId = tracks[0]?.id || "";
    await saveTracksJson();

    renderList();
    renderEditor();
    setPill(el.saveState, "Törölve", "ok");
  } catch (e) {
    alert(String(e?.message || e));
  }
}

/* link resolver (auto fill) */
function scheduleResolve(url) {
  clearTimeout(resolveTimer);
  if (!url) return;
  resolveTimer = setTimeout(async () => {
    try {
      const data = await resolveFromUrl(url);
      const t = currentTrack();
      if (!t) return;

      // töltsük ki
      t.sourceType = data.sourceType || t.sourceType || "";
      t.sourceUrl = data.sourceUrl || t.sourceUrl || "";
      if (data.title) t.title = data.title;
      if (data.publishers?.length) t.publishers = data.publishers;
      if (data.coverUrl && !t.coverPath) t.coverUrl = data.coverUrl;

      t.updatedAt = Date.now();

      renderList();
      renderEditor();
      scheduleSave();
    } catch (e) {
      // ne idegesítsünk, csak log
      console.warn(e);
    }
  }, 450);
}

/* boot */
applyCfgToInputs();
setPill(el.connState, cfg.token ? "?" : "nincs bekötve", cfg.token ? "warn" : "warn");
setPill(el.saveState, "—");

async function boot() {
  try {
    tracks = await loadTracksFromSite({ cacheBust: true });
    tracks.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  } catch {
    tracks = [];
  }
  if (!tracks.length) {
    const now = Date.now();
    tracks.push({
      id: makeId(),
      title: "",
      publishers: [],
      coverUrl: "",
      coverPath: "",
      audioPath: "",
      sourceType: "",
      sourceUrl: "",
      createdAt: now,
      updatedAt: now
    });
  }
  selectedId = tracks[0].id;
  renderList();
  renderEditor();
}
await boot();

/* events */
el.saveConnBtn.addEventListener("click", () => {
  cfg = cfgFromInputs();
  saveCfg(cfg);
  alert("Mentve. Nyomj egy Teszt-et, ha akarod.");
});

el.testConnBtn.addEventListener("click", testConn);

el.newBtn.addEventListener("click", () => {
  const now = Date.now();
  const t = {
    id: makeId(),
    title: "",
    publishers: [],
    coverUrl: "",
    coverPath: "",
    audioPath: "",
    sourceType: "",
    sourceUrl: "",
    createdAt: now,
    updatedAt: now
  };
  tracks.unshift(t);
  select(t.id);
  scheduleSave(true);
});

el.sourceUrl.addEventListener("input", () => {
  patchCurrent({ sourceUrl: el.sourceUrl.value.trim() });
  scheduleResolve(el.sourceUrl.value.trim());
});

el.title.addEventListener("input", () => patchCurrent({ title: el.title.value }));
el.publishers.addEventListener("input", () => patchCurrent({ publishers: splitPublishers(el.publishers.value) }));
el.coverUrl.addEventListener("input", () => patchCurrent({ coverUrl: el.coverUrl.value.trim() }));

el.audioFile.addEventListener("change", () => scheduleSave(true));
el.coverFile.addEventListener("change", () => scheduleSave(true));

el.delBtn.addEventListener("click", deleteCurrent);
