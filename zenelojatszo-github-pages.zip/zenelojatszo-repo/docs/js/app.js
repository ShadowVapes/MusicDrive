import {
  loadTracksFromSite,
  coverSrc,
  audioSrc,
  joinPublishers,
  formatTime
} from "./common.js";

const els = {
  grid: document.getElementById("grid"),
  empty: document.getElementById("empty"),
  trackCount: document.getElementById("trackCount"),
  search: document.getElementById("search"),
  refreshBtn: document.getElementById("refreshBtn"),

  nowCover: document.getElementById("nowCover"),
  nowTitle: document.getElementById("nowTitle"),
  nowSub: document.getElementById("nowSub"),
  openSource: document.getElementById("openSource"),

  prevBtn: document.getElementById("prevBtn"),
  playBtn: document.getElementById("playBtn"),
  nextBtn: document.getElementById("nextBtn"),
  seek: document.getElementById("seek"),
  curTime: document.getElementById("curTime"),
  durTime: document.getElementById("durTime"),
  vol: document.getElementById("vol"),

  audio: document.getElementById("audio")
};

let tracks = [];
let filtered = [];
let activeId = "";
let lastJson = "";

function htmlEscape(s) {
  return String(s || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function render() {
  const q = String(els.search.value || "").trim().toLowerCase();
  filtered = tracks.filter((t) => {
    const title = String(t.title || "").toLowerCase();
    const pubs = joinPublishers(t.publishers || []).toLowerCase();
    return !q || title.includes(q) || pubs.includes(q);
  });

  els.trackCount.textContent = String(filtered.length);

  els.grid.innerHTML = "";
  if (!filtered.length) {
    els.empty.classList.remove("hidden");
    return;
  }
  els.empty.classList.add("hidden");

  for (const t of filtered) {
    const card = document.createElement("div");
    card.className = "card" + (t.id === activeId ? " active" : "");
    card.dataset.id = t.id;

    const csrc = coverSrc(t);
    card.innerHTML = `
      <div class="cover">
        ${csrc ? `<img loading="lazy" src="${htmlEscape(csrc)}" alt="" />` : `<div class="muted">🎵</div>`}
      </div>
      <div class="card-title">${htmlEscape(t.title || "—")}</div>
      <div class="card-sub">${htmlEscape(joinPublishers(t.publishers || []) || "—")}</div>
      <div class="badges">
        ${t.sourceType ? `<span class="badge">${htmlEscape(t.sourceType)}</span>` : ""}
        ${audioSrc(t) ? `<span class="badge">mp3</span>` : ""}
      </div>
    `;
    card.addEventListener("click", () => playById(t.id));
    els.grid.appendChild(card);
  }
}

function setNow(track) {
  const csrc = coverSrc(track);
  els.nowCover.innerHTML = csrc ? `<img src="${htmlEscape(csrc)}" alt="" />` : "";
  els.nowTitle.textContent = track?.title || "—";
  els.nowSub.textContent = joinPublishers(track?.publishers || []) || "—";
  const url = String(track?.sourceUrl || "").trim();
  els.openSource.href = url || "#";
  els.openSource.style.pointerEvents = url ? "auto" : "none";
  els.openSource.style.opacity = url ? "1" : ".55";
}

function activeIndex() {
  return filtered.findIndex((t) => t.id === activeId);
}

function playById(id) {
  const t = filtered.find((x) => x.id === id) || tracks.find((x) => x.id === id);
  if (!t) return;

  const src = audioSrc(t);
  if (!src) {
    alert("Ehhez még nincs feltöltött mp3.");
    return;
  }

  activeId = t.id;
  setNow(t);

  if (els.audio.src !== new URL(src, location.href).toString()) {
    els.audio.src = src;
  }

  els.audio.play().catch(() => {});
  render();
}

function next() {
  if (!filtered.length) return;
  const i = activeIndex();
  const n = i < 0 ? 0 : (i + 1) % filtered.length;
  playById(filtered[n].id);
}

function prev() {
  if (!filtered.length) return;
  const i = activeIndex();
  const p = i <= 0 ? filtered.length - 1 : i - 1;
  playById(filtered[p].id);
}

function toggle() {
  if (!els.audio.src) {
    // play first playable
    const first = filtered.find((t) => audioSrc(t));
    if (first) playById(first.id);
    return;
  }
  if (els.audio.paused) els.audio.play().catch(() => {});
  else els.audio.pause();
}

function syncPlayIcon() {
  els.playBtn.textContent = els.audio.paused ? "▶" : "⏸";
}

function syncTimes() {
  els.curTime.textContent = formatTime(els.audio.currentTime || 0);
  els.durTime.textContent = formatTime(els.audio.duration || 0);

  const dur = els.audio.duration || 0;
  const cur = els.audio.currentTime || 0;
  const v = dur ? Math.min(1000, Math.max(0, Math.floor((cur / dur) * 1000))) : 0;
  els.seek.value = String(v);
}

async function refreshTracks({ forceRender = false } = {}) {
  try {
    const list = await loadTracksFromSite({ cacheBust: true });
    // stable ordering: newest first
    list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    const json = JSON.stringify(list);
    if (forceRender || json !== lastJson) {
      lastJson = json;
      tracks = list;
      render();

      // keep selection if possible
      if (activeId && !tracks.some((t) => t.id === activeId)) {
        activeId = "";
        setNow(null);
      }
    }
  } catch (e) {
    // ignore spam
    console.warn(e);
  }
}

/* events */
els.search.addEventListener("input", render);
els.refreshBtn.addEventListener("click", () => refreshTracks({ forceRender: true }));

els.nextBtn.addEventListener("click", next);
els.prevBtn.addEventListener("click", prev);
els.playBtn.addEventListener("click", toggle);

els.vol.addEventListener("input", () => {
  els.audio.volume = Math.max(0, Math.min(1, Number(els.vol.value) / 100));
});

els.seek.addEventListener("input", () => {
  const dur = els.audio.duration || 0;
  const v = Number(els.seek.value) / 1000;
  if (dur) els.audio.currentTime = dur * v;
});

els.audio.addEventListener("play", syncPlayIcon);
els.audio.addEventListener("pause", syncPlayIcon);
els.audio.addEventListener("timeupdate", syncTimes);
els.audio.addEventListener("loadedmetadata", syncTimes);
els.audio.addEventListener("ended", next);

/* boot */
els.audio.volume = 0.8;
syncPlayIcon();
setNow(null);

await refreshTracks({ forceRender: true });
// “a lehető leggyorsabban” – de ne verjük szét a GitHub cache-t
setInterval(() => refreshTracks({ forceRender: false }), 2500);
