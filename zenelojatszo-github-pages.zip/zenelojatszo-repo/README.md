# Zenelejátszó – GitHub Pages only (admin feltöltés + gyors frissülés)

Ez a repo úgy van összerakva, hogy **csak GitHubon** fusson: a weboldal a `docs/` mappából megy (GitHub Pages),
backend **nincs**.

## Amit tud
- **Admin oldal** (`/admin.html`)
  - MP3 feltöltés
  - borítókép feltöltés
  - cím + kiadó/előadó(k)
  - YouTube / Spotify link → **azonnal** kitölti a címet/előadót/borítót (gomb nélkül)
  - **autosave**: gépelés/feltöltés után magától ment
  - mentés: a repo `docs/data/tracks.json` + `docs/media/*` fájlokat frissíti **GitHub API-n** keresztül
- **User oldal** (`/index.html`)
  - modern, mobilbarát “Spotify‑szerű” UI
  - lejátszás HTML5 audio-val
  - **gyors frissülés**: 2.5 mp-enként újratölti a tracklistát (cache‑bypass)

## GitHub Pages bekapcsolás
1. Repo → **Settings → Pages**
2. Build and deployment → **Deploy from a branch**
3. Branch: `main` (vagy amit használsz), Folder: **/docs**
4. Ennyi. A Jekyllt a `docs/.nojekyll` letiltja.

Ha eddig a Pages build hibázott `.../docs` miatt, ez most megoldja: a mappa itt van.

## Admin beállítás (Token)
Mivel GitHub Pages statikus, az admin mentéshez kell egy token.

1. GitHub → **Settings → Developer settings → Personal access tokens**
2. Csinálj **fine-grained PAT**-et erre a repóra
3. Jogosultság: **Contents: Read and write**
4. Nyisd meg az Admin oldalt, töltsd ki:
   - Owner / Repo / Branch
   - Token
   - Nyomj egy **Teszt**-et (csak ellenőrzés)

> A token csak a böngésződben tárolódik (localStorage), a user oldalon nem kell.

## Fájlok, amiket az admin ír
- `docs/data/tracks.json`
- `docs/media/audio/*`
- `docs/media/covers/*`

## Fontos
- GitHub Contents API-nál a fájlméret plafon kb. **100MB**. Ha a zenéd nagyobb, tömöríts / konvertálj.

---

MIT License
